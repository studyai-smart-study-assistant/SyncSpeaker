import { useEffect, useMemo, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { SyncSpeaker, type DeviceInfo, type HostInfo } from './plugin';

type Role = 'host' | 'speaker';

export default function App() {
  const native = Capacitor.isNativePlatform();
  const [role, setRole] = useState<Role>('host');
  const [hosts, setHosts] = useState<HostInfo[]>([]);
  const [devices, setDevices] = useState<DeviceInfo[]>([]);
  const [trackName, setTrackName] = useState('');
  const [status, setStatus] = useState('Ready');

  const trackLabel = useMemo(() => trackName || 'No track selected', [trackName]);

  useEffect(() => {
    const subscriptions = [
      SyncSpeaker.addListener('hostFound', (data) => {
        const host = data as HostInfo;
        setHosts(prev => prev.some(x => x.host === host.host && x.controlPort === host.controlPort) ? prev : [...prev, host]);
      }),
      SyncSpeaker.addListener('hostLost', (data) => {
        const host = data as HostInfo;
        setHosts(prev => prev.filter(x => !(x.host === host.host && x.controlPort === host.controlPort)));
      }),
      SyncSpeaker.addListener('device', (data) => setDevices(Array.isArray(data?.devices) ? data.devices : [])),
      SyncSpeaker.addListener('command', async (data) => {
        if (data?.type === 'WELCOME') setStatus('Connected — waiting for music');
        if (data?.type === 'PREPARE') {
          setStatus('Downloading track…');
          try {
            await SyncSpeaker.downloadTrack({ url: String(data.url), name: String(data.name || 'track') });
            setStatus('Ready — waiting for synchronized start');
          } catch (error) {
            setStatus(error instanceof Error ? error.message : 'Track download failed');
          }
        }
        if (data?.type === 'PLAY') {
          await SyncSpeaker.schedulePlay({ hostTimeMs: Number(data.hostTimeMs) });
          setStatus('Playing in sync');
        }
        if (data?.type === 'STOP') {
          await SyncSpeaker.stopPlayback();
          setStatus('Stopped');
        }
      })
    ];
    return () => { void Promise.all(subscriptions.map(async p => (await p).remove())); };
  }, []);

  async function chooseTrack(file: File | null) {
    if (!file) return;
    if (!native) { setTrackName(file.name); setStatus('Browser preview only — use the APK for native LAN playback.'); return; }
    setStatus('Copying track to host…');
    setTrackName(file.name);
    const bytes = new Uint8Array(await file.arrayBuffer());
    const chunkSize = 256 * 1024;
    await SyncSpeaker.clearTrack();
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      const chunk = bytes.slice(offset, Math.min(offset + chunkSize, bytes.length));
      let binary = '';
      for (let i = 0; i < chunk.length; i += 0x8000) binary += String.fromCharCode(...chunk.subarray(i, i + 0x8000));
      await SyncSpeaker.writeTrackChunk({ name: file.name, chunkBase64: btoa(binary), offset, totalBytes: bytes.length });
    }
    await SyncSpeaker.prepareLocal();
    setStatus('Track ready');
  }

  async function startHost() {
    await SyncSpeaker.startHost({ serviceName: 'SyncSpeaker' });
    setRole('host');
    setStatus('Host online — waiting for speakers');
  }

  async function discover() {
    setHosts([]);
    await SyncSpeaker.discover();
    setRole('speaker');
    setStatus('Searching this local network…');
  }

  async function join(host: HostInfo) {
    await SyncSpeaker.connect({ host: host.host, port: host.controlPort });
    setStatus('Connected — waiting for track');
  }

  async function startSync() {
    setStatus('Preparing every speaker…');
    await SyncSpeaker.startSynchronizedPlayback({ leadMs: 2500 });
    setStatus('Synchronized playback started');
  }

  return <main className="app-shell">
    <section className="hero">
      <div className="eyebrow">LOCAL AUDIO MESH</div>
      <h1>SyncSpeaker</h1>
      <p>Turn nearby Android phones into one synchronized speaker.</p>
      <div className="mode-tabs">
        <button className={role === 'host' ? 'active' : ''} onClick={() => setRole('host')}>Host</button>
        <button className={role === 'speaker' ? 'active' : ''} onClick={() => setRole('speaker')}>Speaker</button>
      </div>
    </section>

    <section className="card">
      <div className="status-row"><span className="dot" />{status}</div>
      {role === 'host' ? <>
        <label className="file-picker"><input type="file" accept="audio/*" onChange={e => void chooseTrack(e.target.files?.[0] ?? null)} /><span>Choose local music</span></label>
        <div className="track">{trackLabel}</div>
        <button className="primary" onClick={() => void startHost()} disabled={!native}>Start Host</button>
        <button className="primary secondary" onClick={() => void startSync()} disabled={!native || !trackName}>Prepare + Play in Sync</button>
        <div className="device-list"><div className="section-title">Connected speakers</div>
          {devices.length === 0 && <div className="muted">No speakers connected yet.</div>}
          {devices.map(d => <div className="device" key={d.id}><span>{d.name}</span><span>{d.ready ? 'Ready' : 'Connected'}</span></div>)}
        </div>
      </> : <>
        <button className="primary" onClick={() => void discover()} disabled={!native}>Find Local Host</button>
        <div className="device-list"><div className="section-title">Nearby hosts</div>
          {hosts.length === 0 && <div className="muted">No SyncSpeaker host found.</div>}
          {hosts.map(host => <button className="host-row" key={host.host + ':' + host.controlPort} onClick={() => void join(host)}><span>{host.name}</span><span>{host.host}:{host.controlPort}</span></button>)}
        </div>
      </>}
      {!native && <div className="warning">This browser UI is only a shell. Install the Android APK for local network and synchronized playback.</div>}
    </section>
    <footer>Local mode: no cloud backend required.</footer>
  </main>;
}
