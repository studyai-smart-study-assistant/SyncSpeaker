import type { PluginListenerHandle } from '@capacitor/core';

export interface SyncSpeakerPlugin {
  startHost(options?: { serviceName?: string }): Promise<{ host: string; controlPort: number; httpPort: number }>;
  stopHost(): Promise<void>;
  discover(): Promise<{ started: boolean }>;
  stopDiscovery(): Promise<void>;
  connect(options: { host: string; port: number }): Promise<{ connected: boolean }>;
  disconnect(): Promise<void>;
  writeTrackChunk(options: { name: string; chunkBase64: string; offset: number; totalBytes: number }): Promise<{ complete: boolean }>;
  clearTrack(): Promise<void>;
  getStatus(): Promise<Record<string, unknown>>;
  prepareLocal(): Promise<{ prepared: boolean; name?: string }>;
  downloadTrack(options: { url: string; name: string }): Promise<{ downloaded: boolean; path: string }>;
  schedulePlay(options: { hostTimeMs: number }): Promise<{ scheduled: boolean; localTimeMs: number }>;
  stopPlayback(): Promise<void>;
  startSynchronizedPlayback(options?: { leadMs?: number }): Promise<{ hostTimeMs: number }>;
  addListener(eventName: string, listenerFunc: (...args: any[]) => any): Promise<PluginListenerHandle>;
}
