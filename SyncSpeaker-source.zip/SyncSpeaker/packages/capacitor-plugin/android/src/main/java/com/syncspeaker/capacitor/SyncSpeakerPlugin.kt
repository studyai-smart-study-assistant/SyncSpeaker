package com.syncspeaker.capacitor

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

@CapacitorPlugin(name = "SyncSpeaker")
class SyncSpeakerPlugin : Plugin() {
    private val controlPort = 40420
    private val httpPort = 40421
    private val handler = Handler(Looper.getMainLooper())
    private val deviceId = UUID.randomUUID().toString().take(8)
    private val deviceName = "SyncSpeaker-$deviceId"

    private var trackFile: File? = null
    private var mediaPlayer: MediaPlayer? = null
    private var controlServer: ServerSocket? = null
    private var httpServer: ServerSocket? = null
    private var hostRunning = false
    private var clientSocket: Socket? = null
    private var clientWriter: OutputStream? = null
    @Volatile private var clockOffsetMs = 0L

    private var nsdManager: NsdManager? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    private data class ClientConnection(
        val id: String,
        val socket: Socket,
        val writer: OutputStream,
        @Volatile var ready: Boolean = false
    )

    private val clients = ConcurrentHashMap<String, ClientConnection>()

    override fun load() {
        nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    }

    @PluginMethod
    fun startHost(call: PluginCall) {
        if (hostRunning) {
            call.resolve(hostResult())
            return
        }
        hostRunning = true
        thread(name = "syncspeaker-control") { runControlServer() }
        thread(name = "syncspeaker-http") { runHttpServer() }
        registerService(call.getString("serviceName") ?: "SyncSpeaker")
        handler.postDelayed({ call.resolve(hostResult()) }, 300)
    }

    @PluginMethod
    fun stopHost(call: PluginCall) {
        stopHostInternal()
        call.resolve()
    }

    @PluginMethod
    fun discover(call: PluginCall) {
        stopDiscoveryInternal()
        val type = "_syncspeaker._tcp."
        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                call.resolve(JSObject().put("started", true))
            }
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                nsdManager?.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(si: NsdServiceInfo, errorCode: Int) {
                        notifyListeners("error", JSObject().put("message", "Host resolve failed: $errorCode"))
                    }
                    override fun onServiceResolved(si: NsdServiceInfo) {
                        val host = si.host?.hostAddress ?: return
                        if (host == localIpv4()) return
                        notifyListeners("hostFound", JSObject()
                            .put("name", si.serviceName ?: "SyncSpeaker")
                            .put("host", host)
                            .put("controlPort", si.port)
                            .put("httpPort", httpPort))
                    }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                notifyListeners("hostLost", JSObject()
                    .put("name", serviceInfo.serviceName ?: "SyncSpeaker"))
            }
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                notifyListeners("error", JSObject().put("message", "Discovery failed: $errorCode"))
                nsdManager?.stopServiceDiscovery(this)
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
            override fun onDiscoveryStopped(serviceType: String) = Unit
        }
        nsdManager?.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
    }

    @PluginMethod
    fun stopDiscovery(call: PluginCall) {
        stopDiscoveryInternal()
        call.resolve()
    }

    @PluginMethod
    fun connect(call: PluginCall) {
        val host = call.getString("host") ?: return call.reject("host is required")
        val port = call.getInt("port") ?: controlPort
        thread(name = "syncspeaker-client") {
            try {
                val socket = Socket(host, port)
                clientSocket = socket
                clientWriter = socket.getOutputStream()
                sendLine(clientWriter!!, JSONObject()
                    .put("type", "HELLO")
                    .put("id", deviceId)
                    .put("name", deviceName))
                call.resolve(JSObject().put("connected", true))
                readClientLoop(socket)
            } catch (e: Exception) {
                call.reject("Connect failed: ${e.message}", e)
            }
        }
    }

    @PluginMethod
    fun disconnect(call: PluginCall) {
        try { clientWriter?.let { sendLine(it, JSONObject().put("type", "BYE")) } } catch (_: Exception) {}
        try { clientSocket?.close() } catch (_: Exception) {}
        clientSocket = null
        clientWriter = null
        call.resolve()
    }

    @PluginMethod
    fun writeTrackChunk(call: PluginCall) {
        val name = call.getString("name") ?: return call.reject("name is required")
        val encoded = call.getString("chunkBase64") ?: return call.reject("chunkBase64 is required")
        val offset = call.getInt("offset") ?: 0
        val total = call.getInt("totalBytes") ?: 0
        try {
            val safe = name.replace(Regex("[^a-zA-Z0-9._ -]"), "_")
            val partial = File(context.cacheDir, "syncspeaker_$safe.part")
            if (offset == 0) partial.delete()
            FileOutputStream(partial, true).use { it.write(Base64.decode(encoded, Base64.DEFAULT)) }
            if (total > 0 && partial.length() >= total) {
                val finalFile = File(context.cacheDir, "syncspeaker_track_$deviceId")
                partial.copyTo(finalFile, overwrite = true)
                partial.delete()
                trackFile = finalFile
            }
            call.resolve(JSObject().put("complete", trackFile != null))
        } catch (e: Exception) {
            call.reject("Track write failed: ${e.message}", e)
        }
    }

    @PluginMethod
    fun clearTrack(call: PluginCall) {
        trackFile?.delete()
        trackFile = null
        call.resolve()
    }

    @PluginMethod
    fun getStatus(call: PluginCall) {
        call.resolve(JSObject()
            .put("deviceId", deviceId)
            .put("deviceName", deviceName)
            .put("hostRunning", hostRunning)
            .put("connected", clientSocket?.isConnected == true)
            .put("trackReady", trackFile?.exists() == true)
            .put("deviceCount", clients.size))
    }

    @PluginMethod
    fun prepareLocal(call: PluginCall) {
        try {
            val file = trackFile ?: throw IllegalStateException("No local track")
            prepareFile(file)
            call.resolve(JSObject().put("prepared", true).put("name", file.name))
        } catch (e: Exception) {
            call.reject("Prepare failed: ${e.message}", e)
        }
    }

    @PluginMethod
    fun downloadTrack(call: PluginCall) {
        val url = call.getString("url") ?: return call.reject("url is required")
        val name = call.getString("name") ?: "track"
        thread(name = "syncspeaker-download") {
            try {
                val safeName = name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                val target = File(context.cacheDir, "syncspeaker_remote_$safeName")
                URL(url).openConnection().getInputStream().use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output, 64 * 1024) }
                }
                trackFile = target
                prepareFile(target)
                clientWriter?.let { sendLine(it, JSONObject().put("type", "READY")) }
                call.resolve(JSObject().put("downloaded", true).put("path", target.absolutePath))
            } catch (e: Exception) {
                call.reject("Download failed: ${e.message}", e)
            }
        }
    }

    @PluginMethod
    fun schedulePlay(call: PluginCall) {
        val hostTimeMs = call.getLong("hostTimeMs") ?: return call.reject("hostTimeMs is required")
        val localTimeMs = hostTimeMs - clockOffsetMs
        val delay = (localTimeMs - System.currentTimeMillis()).coerceAtLeast(0L)
        handler.postDelayed({ mediaPlayer?.start() }, delay)
        call.resolve(JSObject().put("scheduled", true).put("localTimeMs", localTimeMs))
    }

    @PluginMethod
    fun stopPlayback(call: PluginCall) {
        mediaPlayer?.let { if (it.isPlaying) it.pause(); it.seekTo(0) }
        if (hostRunning) broadcast(JSONObject().put("type", "STOP"))
        call.resolve()
    }

    @PluginMethod
    fun startSynchronizedPlayback(call: PluginCall) {
        if (!hostRunning) return call.reject("Host is not running")
        val track = trackFile ?: return call.reject("No track loaded")
        val leadMs = call.getLong("leadMs") ?: 2500L
        clients.values.forEach { it.ready = false }

        if (clients.isNotEmpty()) {
            broadcast(JSONObject()
                .put("type", "PREPARE")
                .put("url", "http://${localIpv4()}:$httpPort/track")
                .put("name", track.name))
        }

        thread(name = "syncspeaker-ready-barrier") {
            val deadline = System.currentTimeMillis() + 12000L
            while (clients.isNotEmpty() && System.currentTimeMillis() < deadline) {
                if (clients.values.all { it.ready }) break
                Thread.sleep(100)
            }

            val startAt = System.currentTimeMillis() + leadMs
            broadcast(JSONObject().put("type", "PLAY").put("hostTimeMs", startAt))
            handler.postDelayed({ mediaPlayer?.start() }, leadMs)
            handler.post { call.resolve(JSObject().put("hostTimeMs", startAt)) }
        }
    }

    private fun prepareFile(file: File) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build())
            setDataSource(file.absolutePath)
            prepare()
        }
    }

    private fun runControlServer() {
        try {
            controlServer = ServerSocket(controlPort)
            while (hostRunning) {
                val socket = controlServer?.accept() ?: break
                thread { handleHostClient(socket) }
            }
        } catch (_: Exception) {}
    }

    private fun handleHostClient(socket: Socket) {
        socket.use { s ->
            val reader = BufferedReader(InputStreamReader(s.getInputStream()))
            val writer = s.getOutputStream()
            var id = s.inetAddress.hostAddress ?: UUID.randomUUID().toString()
            while (hostRunning) {
                val line = reader.readLine() ?: break
                when (val type = JSONObject(line).optString("type")) {
                    "HELLO" -> {
                        val obj = JSONObject(line)
                        id = obj.optString("id", id)
                        clients[id] = ClientConnection(id, s, writer)
                        sendLine(writer, JSONObject()
                            .put("type", "WELCOME")
                            .put("serverTimeMs", System.currentTimeMillis())
                            .put("trackUrl", "http://${localIpv4()}:$httpPort/track"))
                        emitDevices()
                    }
                    "SYNC" -> {
                        val t1 = JSONObject(line).optLong("t1")
                        val t2 = System.currentTimeMillis()
                        val t3 = System.currentTimeMillis()
                        sendLine(writer, JSONObject().put("type", "PONG").put("t1", t1).put("t2", t2).put("t3", t3))
                    }
                    "READY" -> {
                        clients[id]?.ready = true
                        emitDevices()
                    }
                    else -> if (type == "BYE") break
                }
            }
            clients.remove(id)
            emitDevices()
        }
    }

    private fun readClientLoop(socket: Socket) {
        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
        while (true) {
            val line = reader.readLine() ?: break
            val obj = JSONObject(line)
            when (obj.optString("type")) {
                "WELCOME" -> {
                    notifyListeners("command", JSObject()
                        .put("type", "WELCOME")
                        .put("serverTimeMs", obj.optLong("serverTimeMs"))
                        .put("trackUrl", obj.optString("trackUrl")))
                    sendSyncPing()
                }
                "PONG" -> {
                    val t4 = System.currentTimeMillis()
                    val t1 = obj.optLong("t1")
                    val t2 = obj.optLong("t2")
                    val t3 = obj.optLong("t3")
                    clockOffsetMs = ((t2 - t1) + (t3 - t4)) / 2
                    notifyListeners("syncUpdate", JSObject().put("offsetMs", clockOffsetMs))
                    handler.postDelayed({ sendSyncPing() }, 1500)
                }
                "PREPARE" -> notifyListeners("command", JSObject()
                    .put("type", "PREPARE")
                    .put("url", obj.optString("url"))
                    .put("name", obj.optString("name")))
                "PLAY" -> notifyListeners("command", JSObject()
                    .put("type", "PLAY")
                    .put("hostTimeMs", obj.optLong("hostTimeMs")))
                "STOP" -> notifyListeners("command", JSObject().put("type", "STOP"))
            }
        }
    }

    private fun sendSyncPing() {
        try {
            clientWriter?.let { sendLine(it, JSONObject().put("type", "SYNC").put("t1", System.currentTimeMillis())) }
        } catch (_: Exception) {}
    }

    private fun runHttpServer() {
        try {
            httpServer = ServerSocket(httpPort)
            while (hostRunning) {
                val socket = httpServer?.accept() ?: break
                thread { serveTrack(socket) }
            }
        } catch (_: Exception) {}
    }

    private fun serveTrack(socket: Socket) {
        socket.use { s ->
            val reader = BufferedReader(InputStreamReader(BufferedInputStream(s.getInputStream())))
            val requestLine = reader.readLine() ?: return
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
            }
            if (!requestLine.startsWith("GET ")) return
            val file = trackFile ?: return
            val output = s.getOutputStream()
            val header = "HTTP/1.1 200 OK\\r\\nContent-Type: application/octet-stream\\r\\nContent-Length: ${file.length()}\\r\\nConnection: close\\r\\n\\r\\n"
            output.write(header.toByteArray())
            file.inputStream().use { it.copyTo(output, 64 * 1024) }
            output.flush()
        }
    }

    private fun registerService(serviceName: String) {
        val info = NsdServiceInfo().apply {
            this.serviceName = serviceName
            serviceType = "_syncspeaker._tcp"
            port = controlPort
        }
        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) = Unit
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                notifyListeners("error", JSObject().put("message", "NSD registration failed: $errorCode"))
            }
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
        }
        nsdManager?.registerService(info, NsdManager.PROTOCOL_DNS_SD, registrationListener)
    }

    private fun stopHostInternal() {
        hostRunning = false
        try { controlServer?.close() } catch (_: Exception) {}
        try { httpServer?.close() } catch (_: Exception) {}
        clients.values.forEach { try { it.socket.close() } catch (_: Exception) {} }
        clients.clear()
        registrationListener?.let { try { nsdManager?.unregisterService(it) } catch (_: Exception) {} }
        registrationListener = null
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private fun stopDiscoveryInternal() {
        discoveryListener?.let { try { nsdManager?.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discoveryListener = null
    }

    private fun hostResult() = JSObject()
        .put("host", localIpv4())
        .put("controlPort", controlPort)
        .put("httpPort", httpPort)

    private fun emitDevices() {
        val array = org.json.JSONArray()
        clients.values.forEach { client ->
            array.put(JSONObject()
                .put("id", client.id)
                .put("name", client.id)
                .put("ready", client.ready)
                .put("connected", true))
        }
        notifyListeners("device", JSObject().put("devices", array))
    }

    private fun broadcast(obj: JSONObject) {
        clients.values.toList().forEach { client ->
            try { sendLine(client.writer, obj) } catch (_: Exception) {}
        }
    }

    private fun sendLine(output: OutputStream, json: JSONObject) {
        synchronized(output) {
            output.write((json.toString() + "\\n").toByteArray())
            output.flush()
        }
    }

    private fun localIpv4(): String {
        return try {
            java.net.NetworkInterface.getNetworkInterfaces().toList().forEach { ni ->
                if (!ni.isUp || ni.isLoopback) return@forEach
                ni.inetAddresses.toList().forEach { address ->
                    if (address is Inet4Address && !address.isLoopbackAddress) return address.hostAddress ?: "127.0.0.1"
                }
            }
            "127.0.0.1"
        } catch (_: Exception) { "127.0.0.1" }
    }
}
