# SyncSpeaker 🔊

Local-only multi-phone synchronized speaker experiment.

## Architecture

- React + Vite frontend.
- Capacitor 8 Android shell.
- Custom Android Capacitor plugin.
- mDNS/NSD discovery on the local network.
- Host-local TCP control channel.
- Host-local HTTP track transfer.
- NTP-style clock offset estimation.
- Pre-buffered, scheduled playback with a common future host timestamp.
- No internet/backend dependency in local mode.

## Important limitation

This first foundation targets tight perceptual synchronization, not guaranteed sample-perfect synchronization. Different Android devices can have different audio output latency, DSP paths, and clock drift. A later calibration layer should measure each device's output latency and apply a per-device correction.

## Network strategy

Wi-Fi/LAN is the primary phone-to-phone transport. Bluetooth is intentionally not the primary audio transport in this first version. Wi-Fi Direct/Wi-Fi Aware and Android LE Audio can be added later as separate connectivity paths.

## GitHub Actions

Every push to `main` builds a debug APK and publishes it to a GitHub Release so the APK does not accumulate in Actions artifact storage.

## Development

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```
