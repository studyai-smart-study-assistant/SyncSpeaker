import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.syncspeaker.app',
  appName: 'SyncSpeaker',
  webDir: 'dist'
};

export default config;
